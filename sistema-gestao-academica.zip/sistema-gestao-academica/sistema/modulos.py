def teste():
	print("Teste de módulo.")
