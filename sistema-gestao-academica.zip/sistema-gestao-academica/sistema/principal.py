#Programa principal do projeto
import modulos

modulos.teste()
